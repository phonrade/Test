﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            char oper;

            Console.WriteLine("Input first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Operation: ");
            oper = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Input second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            if (oper == '+')
                Console.WriteLine("{0} + {1} = {2} ", num1, num2, num1 + num2);
            else if (oper == '-')
                Console.WriteLine("{0} - {1} = {2} ", num1, num2, num1 - num2);
            else if (oper == '*')
                Console.WriteLine("{0} * {1} = {2}", num1, num2, num1*num2);
            else if (oper == '/')
                Console.WriteLine("{0} / {1} = {2}", num1, num2, num1 / num2);
            else
                Console.WriteLine("Wrong Character");
        }
    }
}
