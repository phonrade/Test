﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise10
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            bool bothEven;

            Console.WriteLine("Input first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            bothEven = ((num1 % 2 == 0) && (num2 % 2 == 0)) ? true : false;

            Console.WriteLine(bothEven ? "there're number bothEven" : "There's a number odd");
        }
    }
}
