﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            int num;

            Console.Write("Input number: ");
            num = Int32.Parse(Console.ReadLine());

            Console.WriteLine();

            Console.WriteLine("{0}{0}{0}{0}{0}{0}", num);
            Console.WriteLine("{0}{0}{0}{0}{0}", num);
            Console.WriteLine("{0}{0}{0}{0}", num);
            Console.WriteLine("{0}{0}{0}", num);
            Console.WriteLine("{0}{0}", num);
            Console.WriteLine("{0}", num);
        }
        */

        //Actual Answer
        public static void Main()
        {
            Console.Write("Input a number: ");
            int num = Convert.ToInt32(Console.ReadLine());

            Console.Write("Input the desired width: ");
            int width = Convert.ToInt32(Console.ReadLine());

            int height = width;
            for (int row = 0; row < height; row++)
            {
                for (int column = 0; column < width; column++)
                {
                    Console.Write(num);
                }

                Console.WriteLine();
                width--;
            }
        }
    }
}
