﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise79
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Switches("LetzoG"));
            Console.WriteLine(Switches("Leog"));
            Console.WriteLine(Switches("Demongog"));
        }

        public static string Switches(string str)
        {
            if (str.Length > 1)
            {
                return str.Substring(0, str.Length - 2) + str[str.Length - 1] + str[str.Length - 2];
            }
            else
            {
                return str;
            }
        }
    }
}
