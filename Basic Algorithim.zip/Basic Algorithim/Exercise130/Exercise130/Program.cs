﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise130
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = MZero(new[] { 1, 2, 0, 3, 5, 7, 0, 9, 11 });
            Console.Write("New array: ");
            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.WriteLine();
        }

        static int[] MZero(int[] numbers)
        {
            int pos = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] == 0)
                {
                    numbers[i] = numbers[pos];
                    numbers[pos++] = 0;
                }
            }
            return numbers;
        }
    }
}
