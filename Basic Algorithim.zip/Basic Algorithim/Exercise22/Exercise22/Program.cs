﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise22
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Zs("Frizz"));
            Console.WriteLine(Zs("Zane"));
            Console.WriteLine(Zs("Zazz"));
            Console.WriteLine(Zs("false"));
        }

        public static bool Zs(string str)
        {
            int ctr = 0;

            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == 'z')
                {
                    ctr++;
                }
            }
            return ctr > 1 && ctr < 4;
        }
    }
}
