﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise61
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(test("[[]]", "Hello"));
            Console.WriteLine(test("(())", "Hi"));
        }

        public static string test(string s1, string word)
        {
            return s1.Substring(0, 2) + word + s1.Substring(2);
        }
    }
}
