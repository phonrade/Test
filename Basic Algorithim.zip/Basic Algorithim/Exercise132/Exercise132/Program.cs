﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise132
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = EvenOdd(new[] { 1, 2, 5, 3, 5, 4, 6, 9, 11 });
            Console.Write("New array: ");
            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.WriteLine();
        }

        static int[] EvenOdd(int[] numbers)
        {
            int index = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] % 2 == 0)
                {
                    int temp = numbers[index];
                    numbers[index] = numbers[i];
                    numbers[i] = temp;

                    index++;
                }
            }
            return numbers;
        }
    }
}
