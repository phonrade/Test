﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise36
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(StringX("xxHxix", "x"));
            Console.WriteLine(StringX("abxdddca", "a"));
            Console.WriteLine(StringX("xabjbhtrb", "b"));
        }
        public static string StringX(string str1, string c)
        {
            for (int i = str1.Length - 2; i > 0; i --)
            {
                if (str1[i] == c[0])
                {
                    str1 = str1.Remove(i, 1);
                }
            }
            return str1;
        }
    }
}
