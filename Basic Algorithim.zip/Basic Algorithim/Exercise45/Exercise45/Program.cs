﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise45
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(eighteen(3, 7));
            Console.WriteLine(eighteen(10, 11));
            Console.WriteLine(eighteen(10, 20));
            Console.WriteLine(eighteen(21, 220));
        }

        public static int eighteen(int x, int y)
        {
            return (x >= 10 && x <= 20) || (y >= 10 && y <= 20) ? 18 : x + y;
        }
    }
}
