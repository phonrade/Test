﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise84
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Rep("abcab"));
            Console.WriteLine(Rep("Python"));
        }

        public static string Rep(string s1)
        {
            if (s1.Length > 1 && s1.Substring(0, 2) == s1.Substring(s1.Length - 2))
            {
                return s1.Substring(2);
            }
            else
            {
                return s1;
            }
        }
    }
}
