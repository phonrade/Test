﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise108
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = Dos(new[] { 1, 5, 7, 9, 11, 13 });
            Console.Write("New array: ");
            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.WriteLine();
        }

        static int[] Dos(int[] num)
        {
            int[] fron_nums;

            if (num.Length >= 2)
            {
                fron_nums = new int[] { num[0], num[1] };
            }
            else if (num.Length > 0 )
            {
                fron_nums = new int[] { num[0] };
            }
            else
            {
                fron_nums = new int[0];
            }
            return fron_nums;
        }
    }
}
