﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise115
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Fif(new[] { 1, 5, 6, 9, 10, 17 }));
            Console.WriteLine(Fif(new[] { 1, 5, 5, 5, 10, 17 }));
            Console.WriteLine(Fif(new[] { 1, 1, 5, 5, 5, 5 }));
        }

        static bool Fif(int[] nums)
        {
            int sum = 0;

            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] == 5)
                    sum += 5;
            }

            return sum == 15;
        }
    }
}
