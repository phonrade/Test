﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise58
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(thir(3, 10));
            Console.WriteLine(thir(7, 6));
            Console.WriteLine(thir(10, 10));
            Console.WriteLine(thir(7, 3));
        }

        public static int thir(int x, int y)
        {
            if (x + y <= 13)
                return x + y;
            return 0;
        }
        */

        //Actual Answer
        static void Main(string[] args)
        {
            Console.WriteLine(test(4, 5));
            Console.WriteLine(test(7, 12));
            Console.WriteLine(test(10, 13));
            Console.WriteLine(test(17, 33));
            Console.WriteLine(test(17, 33));
            Console.ReadLine();
            Console.WriteLine(test(3, 10));
            Console.WriteLine(test(7, 6));
            Console.WriteLine(test(10, 10));
            Console.WriteLine(test(7, 3));
        }
        public static int test(int x, int y)
        {
            if (x > 13 && y > 13) return 0;
            if (x <= 13 && y > 13) return x;
            if (y <= 13 && x > 13) return y;
            return x > y ? x : y;
        }
    }
}
