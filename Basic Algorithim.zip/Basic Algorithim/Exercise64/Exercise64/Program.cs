﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise64
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Half("Hello"));
            Console.WriteLine(Half("Hi"));
        }

        public static string Half(string str)
        {
            return str.Substring(0, str.Length / 2);
        }
    }
}
