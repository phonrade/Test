﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise126
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Inc(new[] { 1, 2, 3, 5, 3, 7 }));
            Console.WriteLine(Inc(new[] { 3, 7, 5, 5, 3, 7 }));
            Console.WriteLine(Inc(new[] { 3, 7, 5, 5, 6, 7, 5 }));
        }

        static bool Inc(int[] numbers)
        {
            for (int i = 0; i <= numbers.Length - 3; i++)
            {
                if (numbers[i] == numbers[i + 1] - 1
                    && numbers[i] == numbers[i + 2] - 2)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
