﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise50
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(SDigit(11, 21, 31));
            Console.WriteLine(SDigit(11, 22, 31));
            Console.WriteLine(SDigit(11, 22, 33));
        }
        
        public static bool SDigit(int x, int y, int z)
        {
            return x % 10 == y % 10 || x % 10 == z % 10 || y % 10 == z % 10;
        }
    }
}
