﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
namespace Exercise142
{
    class Program
    {
        static void Main(string[] args)
        {
            List mylist = Multi(new List(new int[] { 1, 2, 3, 4 }));
            foreach (var i in mylist)
            {
                Console.Write(i.ToString() + " ");
            }
        }
        public static List Multi(List nums)
        {
            IEnumerable squared = nums.Select(x => x * x * x);
            return squared.ToList();
        }
    }

    public class List
    {
    }
}