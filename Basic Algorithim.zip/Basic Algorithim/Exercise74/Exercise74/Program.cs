﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise74
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Two("Charmander", 2));
            Console.WriteLine(Two("Squirtle", 5));
            Console.WriteLine(Two("Bulbasuar", 3));
        }

        public static string Two(string str, int num)
        {
            return num + 2 <= str.Length ? str.Substring(num, 2) : str.Substring(0, 2);
        }
    }
}
