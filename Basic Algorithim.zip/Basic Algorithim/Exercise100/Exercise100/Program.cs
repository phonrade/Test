﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise100
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(TensDob(new[] { 10, 20 }));
            Console.WriteLine(TensDob(new[] { 20, 20 }));
            Console.WriteLine(TensDob(new[] { 10, 10 }));
        }

        public static bool TensDob(int[] num)
        {
            return num[0] == 10 && num[1] == 10 || num[0] == 20 && num[1] == 20;
        }
        */

        //Actual Answer
        static void Main(string[] args)
        {

            Console.WriteLine(test(new[] { 12, 20 }));
            Console.WriteLine(test(new[] { 20, 20 }));
            Console.WriteLine(test(new[] { 10, 10 }));
            Console.WriteLine(test(new[] { 10 }));

        }

        public static bool test(int[] nums)
        {
            return nums.Length == 2
                && ((nums[0] == 10 && nums[1] == 10)
                     || (nums[0] == 20 && nums[1] == 20));
        }
    }
}
