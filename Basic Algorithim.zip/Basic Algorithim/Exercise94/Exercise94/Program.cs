﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise94
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = Maximum(new[] { 10, 20, -30, -40 });

            Console.WriteLine("New array: ");

            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.ReadLine();
        }

        public static int[] Maximum(int[] nums)
        {
            int max = nums.Max();

            return new int[] { max, max, max, max };
        }
    }
}
