﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise25
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(No("JS", 2));
            Console.WriteLine(No("JS", 3));
            Console.WriteLine(No("JS", 1));
        }

        public static string No(string s, int n)
        {
            string result = String.Empty;
            for (int i = 0; i < n; i++)
            {
                result += s;
            }
            return result;
        }
    }
}
