﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise92
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = Rev(new[] { 10, 20, -30, -40, 50 });

            Console.Write("Reverse array: ");

            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
        }

        public static int[] Rev(int[] nums)
        {
            return new int[] { nums[4], nums[3], nums[2], nums[1], nums[0] };
        }
    }
}
