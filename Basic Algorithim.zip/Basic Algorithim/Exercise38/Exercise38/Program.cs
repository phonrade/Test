﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise38
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(fives(new[] { 5, 5, 2}));
            Console.WriteLine(fives(new[] { 5, 5, 2, 5, 5 }));
            Console.WriteLine(fives(new[] { 5, 6, 2, 9 }));
        }

        public static int fives(int[] numbers)
        {
            var ctr = 0;
            for (var i = 0; i < numbers.Length - 1; i++)
            {
                if (numbers[i].Equals(5) && (numbers[i + 1].Equals(5) || numbers[i + 1].Equals(6))) ctr++;
            }
            return ctr;
        }
    }
}
