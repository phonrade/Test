﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise27
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(copies("bbaaccaagg"));
            Console.WriteLine(copies("jjkiaaasew"));
            Console.WriteLine(copies("JSaaakoiaa"));
            Console.WriteLine(copies("JSaaaakoiaa"));
        }

        public static int copies(string s)
        {
            int ctr_aa = 0;
            for (int i = 0; i < s.Length - 1; i++)
            {
                if (s.Substring(i, 2) == "aa")
                {
                    ctr_aa++;
                }
            }
            return ctr_aa;
        }
    }
}
