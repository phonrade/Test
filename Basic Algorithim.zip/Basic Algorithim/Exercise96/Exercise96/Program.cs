﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise96
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = Uno(new[] { 10, 20, -30, -40, 30 }); 

            Console.Write("New array: ");

            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.ReadLine();
        }

        public static int[] Uno(int[] nums)
        {
            return new int[] { nums[0], nums[nums.Length - 1] };
        }
    }
}
