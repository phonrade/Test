﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise20
{
    class Program
    {
        //My Solution
        
        static void Main(string[] args)
        {
            Console.WriteLine(check(20, 40));
            Console.WriteLine(check(55, 60));
            Console.WriteLine(check(40, 45));
        }

        public static bool check(int x, int y)
        {
            return x >= 40 && x <= 50 && y >= 40 && y <= 50 || x >= 50 && x <= 60 && y >= 50 && y <= 60;
        }
        

        //Actual answer
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(test(78, 95));
            Console.WriteLine(test(25, 35));
            Console.WriteLine(test(40, 50));
            Console.WriteLine(test(55, 60));
            Console.ReadLine();
        }

        public static bool test(int x, int y)
        {
            return (x >= 40 && x <= 50 && y >= 40 && y <= 50) || (x >= 50 && x <= 60 && y >= 50 && y <= 60);
        }
        */
    }
}
