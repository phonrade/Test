﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise117
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(TF(new[] { 5, 5, 5, 5, 5 }));
            Console.WriteLine(TF(new[] { 3, 3, 3, 3 }));
            Console.WriteLine(TF(new[] { 3, 3, 3, 5, 5, 5 }));
            Console.WriteLine(TF(new[] { 1, 6, 8, 10 }));
        }

        static bool TF(int[] nums)
        {
            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] != 3 && nums[i] != 5) return false;
            }
            return true;
        }
    }
}
