﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise121
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(TF(new[] { 3, 5, 1, 3, 7 }));
            Console.WriteLine(TF(new[] { 1, 2, 3, 4 }));
            Console.WriteLine(TF(new[] { 3, 3, 5, 5, 5, 5 }));
            Console.WriteLine(TF(new[] { 2, 5, 5, 7, 8, 10 }));
        }

        static bool TF(int[] numbers)
        {
            bool three = false;

            for (int i = 0; i < numbers.Length; i++)
            {
                if (three && numbers[i] == 5) return true;
                if (numbers[i] == 3) three = true;
            }
            return false;
        }
    }
}
