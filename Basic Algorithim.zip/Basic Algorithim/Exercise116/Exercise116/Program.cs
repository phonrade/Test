﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise116
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Comp(new[] { 1, 5, 6, 9, 3, 3 }));
            Console.WriteLine(Comp(new[] { 1, 5, 5, 5, 10, 7 }));
            Console.WriteLine(Comp(new[] { 1, 3, 3, 5, 5, 5 }));
        }

        static bool Comp(int[] nums)
        {
            int no_3 = 0, no_5 = 0;

            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] == 3) no_3++;
                if (nums[i] == 5) no_5++;
            }

            return no_3 > no_5;
        }
    }
}
