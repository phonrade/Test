﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise102
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(Sup(new[] { 10, 20, 30}, new[] { 15, 15, 5 }));
            Console.WriteLine(Sup(new[] { 13, 5, 7 }, new[] { 8, 13, 5 }));
            Console.WriteLine(Sup(new[] { 1, 25, 15 }, new[] { 6, 34, 21 }));
        }

        public static int Sup(int[] num1, int[] num2)
        {
            int res1 = num1[0] + num1[1] + num1[2];
            int res2 = num2[0] + num2[1] + num2[2];
            
            if (res1 > res2)
            {
                return num1[0];
            }
            return num2[0];

        }
        */

        //Actual Answer

        static void Main(string[] args)
        {
            int[] item = test(new[] { 10, 20, -30 }, new[] { 10, 20, 30 });
            Console.Write("Larger array: ");
            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
        }
        public static int[] test(int[] nums1, int[] nums2)
        {
            return nums1[0] + nums1[1] + nums1[2] >= nums2[0] + nums2[1] + nums2[2] ? nums1 : nums2;
        }
    }
}
