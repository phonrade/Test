﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise47
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(AddThree(1, 2, 3));
            Console.WriteLine(AddThree(25, 13, 12));
            Console.WriteLine(AddThree(-1, 1, 0));
            Console.WriteLine(AddThree(4, 5, 6));
        }

        public static bool AddThree(int x, int y, int z)
        {
            return x == y + z || y == x + z || z == x + y;
        }
    }
}
