﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise150
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> mylist = RSeven(new List<int>(new int[] { 10, 22, 35, 47, 53, 67 }));
            foreach(var i in mylist)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.WriteLine();
        }

        public static List<int> RSeven(List<int> nums)
        {
            return nums.Where(n => n % 10 < 7).ToList();
        }
    }
}
