﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise49
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Inc(1, 2, 3, false));
            Console.WriteLine(Inc(1, 2, 3, true));
            Console.WriteLine(Inc(10, 2, 30, false));
            Console.WriteLine(Inc(10, 10, 30, false));
        }

        public static bool Inc(int x, int y, int z, bool flag)
        {
            return flag ? x <= y && y <= z : x < y && y < z;
        }
    }
}
