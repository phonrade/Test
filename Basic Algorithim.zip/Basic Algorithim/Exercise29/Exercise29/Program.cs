﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise29
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(skip("Python"));
            Console.WriteLine(skip("PHP"));
            Console.WriteLine(skip("Medabots"));
            Console.WriteLine(skip("Pokemon"));
            Console.WriteLine(skip("SoulCaliber"));
        }

        public static string skip(string str)
        {
            var result = string.Empty;
            for (var i = 0; i < str.Length; i++)
            {
                if (i % 2 == 0) result += str[i];
            }
            return result;
        }
    }
}
