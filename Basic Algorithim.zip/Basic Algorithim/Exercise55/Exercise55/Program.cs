﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise55
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Tres(4, 5, 7));
            Console.WriteLine(Tres(7, 4, 12));
            Console.WriteLine(Tres(10, 10, 12));
            Console.WriteLine(Tres(12, 12, 18));
        }

        public static int Tres(int x, int y, int z)
        {
            if (x == y && y == z) return 0;
            if (x == y) return z;
            if (x == z) return y;
            if (y == z) return x;
            return x + y + z;
        }
    }
}
