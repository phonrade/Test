﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise114
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(SF(new[] { 1, 5, 6, 9, 10, 17}));
            Console.WriteLine(SF(new[] { 1, 6, 6, 8, 11, 17 }));
            Console.WriteLine(SF(new[] { 1, 1, 6, 7, 14, 17 }));
            Console.WriteLine(SF(new[] { 5, 1, 6, 7, 1, 7 }));
            Console.WriteLine(SF(new[] { 1, 4, 7, 9, 10, 17 }));
            Console.WriteLine(SF(new[] { 1, 1, 2, 9, 10, 17 }));
        }

        static bool SF(int[] nums)
        {
            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] == 5 || nums[i] == 7) return true;
            }
            return false;
        }
    }
}
