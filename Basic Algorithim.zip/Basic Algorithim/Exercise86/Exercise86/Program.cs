﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise86
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(As("abcab"));
            Console.WriteLine(As("python"));
            Console.WriteLine(As("abcda"));
            Console.WriteLine(As("jython"));
        }

        public static string As(string s1)
        {
            if (s1.Length > 0 && s1.Substring(s1.Length - 1) == "a")
            {
                s1 = s1.Remove(s1.Length - 1);
            }

            if (s1.Length > 0 && s1.Substring(0, 1) == "a")
            {
                s1 = s1.Remove(0, 1);
            }

            return s1;
        }
    }
}
