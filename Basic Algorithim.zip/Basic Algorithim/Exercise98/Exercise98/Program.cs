﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise98
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Un(new[] { 12, 10}));
            Console.WriteLine(Un(new[] { 21, 15 }));
            Console.WriteLine(Un(new[] { 25, 6 }));
        }

        public static bool Un(int[] num)
        {
            return num[0] != 15 && num[0] != 20 && num[1] != 15 && num[1] != 20;
        }
    }
}
