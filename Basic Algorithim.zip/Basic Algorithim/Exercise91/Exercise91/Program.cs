﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise91
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Sum(new[] { 1, 2, 5, 6, 8}));
            Console.WriteLine(Sum(new[] { 10, 50, 7, 8, 8 }));
            Console.WriteLine(Sum(new[] { 5, 4, 65, 9, 10 }));
            Console.WriteLine(Sum(new[] { 10, 20, -30, -40, 50 }));
        }

        public static int Sum(int[] num)
        {
            return num[0] + num[1] + num[2] + num[3] + num[4];
        }
    }
}
