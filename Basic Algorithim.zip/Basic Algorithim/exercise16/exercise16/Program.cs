﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise16
{
    class Program
    {
        //My Solution
        static void Main(string[] args)
        {
            Console.WriteLine(dos(15, 20));
            Console.WriteLine(dos(25, 30));
            Console.WriteLine(dos(25, 50));
            Console.WriteLine(dos(20, 50));
        }

        public static bool dos (int x, int y)
        {
            return x <= 20 || y >= 50 || y <= 20 || x >= 50;
        }
        

        //Actual Answer
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(test(15, 20));
            Console.WriteLine(test(25, 30));
            Console.WriteLine(test(25, 50));
            Console.WriteLine(test(20, 50));
            Console.ReadLine();
        }

        public static bool test(int x, int y)
        {
            return (x <= 20 || y >= 50) || (y <= 20 || x >= 50);
        }
        */
    }
}
