﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise73
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(FL("Micheal", 1));
            Console.WriteLine(FL("Scream", 2));
            Console.WriteLine(FL("Freddy", 1));
        }

        public static string FL(string str, int num)
        {
            return str.Substring(0, num) + str.Substring(str.Length - num);
        }
    }
}
