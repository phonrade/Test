﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise122
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(OE(new[] { 3, 5, 1, 3, 7 }));
            Console.WriteLine(OE(new[] { 1, 2, 3, 4 }));
            Console.WriteLine(OE(new[] { 3, 3, 5, 5, 5, 5 }));
            Console.WriteLine(OE(new[] { 2, 4, 5, 6 }));
        }

        static bool OE(int[] nums)
        {
            int tot_odd = 0, tot_even = 0;

            for (int i = 0; i < nums.Length; i++)
            {
                if (tot_odd < 2 && tot_even < 2)
                {
                    if (nums[i] % 2 == 0)
                    {
                        tot_even++;
                        tot_odd = 0;
                    }
                    else
                    {
                        tot_odd++;
                        tot_even = 0;
                    }
                }
            }
            return tot_odd == 2 || tot_even == 2;
        }
    }
}