﻿using System;

namespace Exercise13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(tempt(120, -1));
            Console.WriteLine(tempt(-1, 120));
            Console.WriteLine(tempt(2, 120));
        }

        public static bool tempt(int temp1, int temp2)
        {
            return temp1 < 0 && temp2 > 100 || temp2 < 0 && temp1 > 100;
        }
    }
}
