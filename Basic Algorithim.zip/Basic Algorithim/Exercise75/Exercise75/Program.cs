﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise75
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(CMC("Center"));
            Console.WriteLine(CMC("Middle"));
            Console.WriteLine(CMC("Core"));
        }

        public static string CMC(string str)
        {
            return str.Substring((str.Length - 1) / 2 - 1, 3);
        }
    }
}
