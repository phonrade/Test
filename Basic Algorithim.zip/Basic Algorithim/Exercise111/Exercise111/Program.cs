﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise111
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sum value of the array of integers execpt for no. 17: ");
            Console.WriteLine(Add(new[] { 1, 5, 7, 9, 10, 17}));
        }

        static int Add(int[] nums)
        {
            int sum = 0;

            for (int i = 0; i < nums.Length; i ++)
            {
                if (nums[i] != 17) sum += nums[i];
                else i++;
            }
            return sum;
        }
    }
}
