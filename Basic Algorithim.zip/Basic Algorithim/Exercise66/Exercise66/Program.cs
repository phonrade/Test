﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise66
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(LS("Hello", "Hi"));
            Console.WriteLine(LS("Halo", "ElfWars"));
            Console.WriteLine(LS("Zero", "X"));
        }

        public static string LS(string L, string S)
        {
            return L.Length < S.Length ? S + L + S : L + S + L;
        }
    }
}
