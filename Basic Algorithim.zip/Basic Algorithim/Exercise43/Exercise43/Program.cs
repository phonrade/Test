﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise43
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(Multis(3));
            Console.WriteLine(Multis(6));
            Console.WriteLine(Multis(42));
            Console.WriteLine(Multis(35));
            Console.WriteLine(Multis(10));
            Console.WriteLine(Multis(17));
        }

        public static bool Multis(int num)
        {
            return num % 3 == 0 || num % 7 == 0;
        }
        */

        //Actual Answer
        static void Main(string[] args)
        {
            Console.WriteLine(test(3));
            Console.WriteLine(test(7));
            Console.WriteLine(test(21));
            Console.ReadLine();
            Console.WriteLine(test(3));
            Console.WriteLine(test(6));
            Console.WriteLine(test(42));
            Console.WriteLine(test(35));
            Console.WriteLine(test(10));
            Console.WriteLine(test(17));
            Console.ReadLine();
        }
        public static bool test(int n)
        {
            return n % 3 == 0 ^ n % 7 == 0;
        }

    }
}
