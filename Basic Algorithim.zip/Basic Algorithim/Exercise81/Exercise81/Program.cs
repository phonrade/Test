﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise81
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(same("abab"));
            Console.WriteLine(same("abcdef"));
            Console.WriteLine(same("xyzsderxy"));
        }

        public static bool same(string s1)
        {
            return s1.Substring(0, 2) == s1.Substring(s1.Length - 2);
        }
    }
}
