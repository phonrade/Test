﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise71
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Mid("Hello"));
            Console.WriteLine(Mid("Pokemon"));
            Console.WriteLine(Mid("Charity"));
        }

        public static string Mid(string str)
        {
            return str.Substring(str.Length / 2 - 1, 2);
        }
    }
}
