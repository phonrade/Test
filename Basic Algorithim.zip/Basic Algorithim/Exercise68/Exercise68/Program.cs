﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise68
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Mov("Jello"));
            Console.WriteLine(Mov("Mongrel"));
            Console.WriteLine(Mov("Sleeper"));
        }

        public static string Mov(string str)
        {
            return str.Remove(0, 2) + str.Substring(0, 2);
        }
    }
}
