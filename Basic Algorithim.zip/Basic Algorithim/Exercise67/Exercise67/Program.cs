﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise67
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Rem("Pokemon", "Digimon"));
            Console.WriteLine(Rem("YuGiOh", "DuelMasters"));
            Console.WriteLine(Rem("Sonic", "Mario"));
        }

        public static string Rem(string str1, string str2)
        {
            return str1.Substring(1) + str2.Substring(1);
        }
    }
}
