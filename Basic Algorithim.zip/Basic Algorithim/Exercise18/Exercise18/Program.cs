﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise18
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(inc(1, 2, 3));
            Console.WriteLine(inc(1, 3, 2));
            Console.WriteLine(inc(1, 1, 1));
            Console.WriteLine(inc(1, 2, 2));
            Console.WriteLine(inc(3, 2, 2));
        }

        public static int inc(int x, int y, int z)
        {
            var max = Math.Max(x, Math.Max(y, z));
            return max;
        }
    }
}
