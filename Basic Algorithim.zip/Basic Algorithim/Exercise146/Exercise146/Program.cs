﻿using System;
using System.Collections.Gen eric;
using System.Linq;
namespace Exercise146
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> mylist = test(new List<int>(new int[] { 10, 22, 35, 41 }));
            foreach (var i in mylist)
            {
                Console.Write(i.ToString() + " ");
            }
        }
        public static List<int> test(List<int> nums)
        {
            IEnumerable<int> digits = nums.Select(x => x % 10);
            return digits.ToList();
        }
    }
}