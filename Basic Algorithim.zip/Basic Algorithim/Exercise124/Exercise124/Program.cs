﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise124
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Fives(new[] { 3, 5, 5, 3, 7 }));
            Console.WriteLine(Fives(new[] { 3, 5, 5, 4, 1, 5, 7 }));
            Console.WriteLine(Fives(new[] { 3, 5, 5, 5, 5, 5 }));
            Console.WriteLine(Fives(new[] { 2, 4, 5, 5, 6, 7, 5 }));
        }

        static bool Fives(int[] numbers)
        {
            int arr_len = numbers.Length;
            bool flag = true;

            for (int i = 0; i < arr_len; i++)
            {
                if (numbers[i] == 5)
                {
                    if ((i > 0 && numbers[i - 1] == 5) || (i < arr_len - 1 && numbers[i + 1] == 5)) flag = true;
                    else if (i == arr_len - 1) flag = false;
                    else return false;
                }
            }
            return flag;
        }
    }
}
