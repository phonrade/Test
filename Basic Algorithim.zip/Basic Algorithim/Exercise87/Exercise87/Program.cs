﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise87
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(AA("abcab"));
            Console.WriteLine(AA("python"));
            Console.WriteLine(AA("aacda"));
            Console.WriteLine(AA("jython"));
        }

        public static string AA(string s1)
        {
            if (s1.Length == 1 && s1.Substring(0, 1) == "a")
            {
                s1 = s1.Remove(0, 1);
            }

            if (s1.Length > 1)
            {
                if (s1.Substring(1, 1) == "a")
                {
                    s1 = s1.Remove(1, 1);
                }

                if (s1.Substring(0, 1) == "a")
                {
                    s1 = s1.Remove(0, 1);
                }
            }

            return s1;
        }
    }
}
