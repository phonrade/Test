﻿using System;

namespace Exercise30
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(alpha("abcd"));
            Console.WriteLine(alpha("abc"));
            Console.WriteLine(alpha("a"));
        }
        public static string alpha(string str)
        {
            var result = string.Empty;
            for (var i = 0; i < str.Length; i++)
            {
                result += str.Substring(0, i + 1);
            }
            return result;
        }
    }
}