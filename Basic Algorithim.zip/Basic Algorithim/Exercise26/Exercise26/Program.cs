﻿using System;

namespace Exercise26
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(tres("Python", 2));
            Console.WriteLine(tres("Python", 3));
            Console.WriteLine(tres("JS", 3));
            Console.WriteLine(tres("JS", 4));
        }

        public static string tres(string s, int n)
        {
            var result = string.Empty;
            var fontOfString = 3;

            if (fontOfString > s.Length)
                fontOfString = s.Length;

            var font = s.Substring(0, fontOfString);

            for (var i = 0; i < n; i++)
            {
                result += font;
            }
            return result;
        }
    }
}
