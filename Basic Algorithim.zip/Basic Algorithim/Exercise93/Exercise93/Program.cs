﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise93
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = test(new[] { 10, 20, -30, -40 });

            Console.Write("Rotated array: ");

            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
        }

        public static int[] test(int[] a1)
        {
            return new int[] { a1[1], a1[2], a1[3], a1[0] };
        }
    }
}
