﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise106
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = Tres(new[] { 1, 5, 7, 9, 11, 13 });
            Console.Write("New Array: ");
            foreach(var i in item)
                {
                Console.Write(i.ToString() + " ");
            }
            Console.WriteLine();
        }

        static int[] Tres(int[] num)
        {
            return new int[] { num[num.Length / 2 - 1], num[num.Length / 2], num[num.Length / 2 + 1] };
        }
    }
}
