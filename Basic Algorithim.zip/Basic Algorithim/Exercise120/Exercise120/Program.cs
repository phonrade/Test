﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise120
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Fives(new[] { 5, 5, 1, 5, 5 }));
            Console.WriteLine(Fives(new[] { 1, 2, 3, 4 }));
            Console.WriteLine(Fives(new[] { 3, 3, 5, 5, 5, 5 }));
            Console.WriteLine(Fives(new[] { 1, 5, 5, 7, 8, 10 }));
        }

        static bool Fives(int[] numbers)
        {
            int len = numbers.Length;

            for (int i = 0; i < len - 1; i++)
            {
                if (numbers[i] == 5 && numbers[i + 1] == 5) return true;
                if (i + 2 < len && numbers[i] == 5 && numbers[i + 2] == 5) return true;
            }

            return false;
        }
    }
}
