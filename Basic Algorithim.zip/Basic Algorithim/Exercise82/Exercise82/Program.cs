﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise82
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Merge("abc", "abcd"));
            Console.WriteLine(Merge("Python", "Python"));
            Console.WriteLine(Merge("JS", "Python"));
        }

        public static string Merge(string s1, string s2)
        {
            if (s1.Length < s2.Length)
            {
                return s1 + s2.Substring(s2.Length - s1.Length);
            }
            else if (s1.Length > s2.Length)
            {
                return s1.Substring(s1.Length - s2.Length) + s2;
            }
            else
            {
                return s1 + s2;
            }
        }
    }
}
