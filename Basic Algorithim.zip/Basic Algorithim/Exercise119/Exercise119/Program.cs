﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise119
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Comp(new[] { 5, 5, 5, 5, 5 }));
            Console.WriteLine(Comp(new[] { 1, 2, 3, 4 }));
            Console.WriteLine(Comp(new[] { 3, 3, 5, 5, 5, 5 }));
            Console.WriteLine(Comp(new[] { 1, 5, 5, 7, 8, 10 }));
        }

        static bool Comp(int[] numbers)
        {
            for (int i = 0; i < numbers.Length - 1; i++) if ((numbers[i] == 3 && numbers[i + 1] == 3) || (numbers[i] == 5 && numbers[i] == 5)) return true;
            return false;
        }
    }
}
