﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise54
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Digit(4, 5));
            Console.WriteLine(Digit(7, 4));
            Console.WriteLine(Digit(10, 10));
        }

        public static int Digit(int x, int y)
        {
            return (x + y).ToString().Length > x.ToString().Length ? x : x + y;
        }
    }
}
