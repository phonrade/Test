﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise99
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = Zero(new[] { 10, 20, -30, -40, 30 });
            Console.Write("New array: ");
            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.ReadLine();
        }
        public static int[] Zero(int[] nums)
        {
            int elements = nums.Length * 2;
            int[] doubleNums = new int[elements];

            doubleNums[0] = nums[0];
            return doubleNums;
        }
    }
}
