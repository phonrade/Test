﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise53
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Bet(11, 21));
            Console.WriteLine(Bet(11, 20));
            Console.WriteLine(Bet(10, 10));
        }

        public static bool Bet(int x, int y)
        {
            return x / 10 == y / 10 || x / 10 == y % 10 || x % 10 == y / 10 || x % 10 == y % 10;
        }
    }
}
