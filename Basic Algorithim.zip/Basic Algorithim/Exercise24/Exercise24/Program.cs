﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise24
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Upper("Python"));
            Console.WriteLine(Upper("JavaScript"));
            Console.WriteLine(Upper("js"));
            Console.WriteLine(Upper("php"));
        }

        public static string Upper(string str)
        {
            return str.Length < 3 ? str.ToUpper() : str.Remove(str.Length - 3) + str.Substring(str.Length - 3).ToUpper();
        }
    }
}
