﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise83
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Copy("abc"));
            Console.WriteLine(Copy("Python"));
            Console.WriteLine(Copy("J"));
        }

        public static string Copy(string s1)
        {
            string extra_Front = String.Empty;

            if (s1.Length < 2)
            {
                return s1 + s1 + s1;
            }
            else
            {
                extra_Front = s1.Substring(0, 2);
                return extra_Front + extra_Front + extra_Front;
            }
        }
    }
}
