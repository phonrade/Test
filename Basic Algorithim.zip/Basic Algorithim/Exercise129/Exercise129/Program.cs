﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise129
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = AFive(new[] { 1, 2, 3, 5, 7, 9, 11 });
            Console.Write("New array: ");
            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.WriteLine();
        }

        static int[] AFive(int[] numbers)
        {
            int len = numbers.Length, size = 0, i = len - 1;
            int[] post_ele_5;

            while (i >= 0 && numbers[i] != 5) i--;
            i++;

            size = len - i;
            post_ele_5 = new int[size];

            for (int j = 0; j < size; j++)
            {
                post_ele_5[j] = numbers[i + j];
            }

            return post_ele_5;
        }
    }
}
