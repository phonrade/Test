﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise95
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = Mid(new[] { 10, 20, -30, -40, 30 }, new[] { 10, 20, 30, 40, 30 });

            Console.Write("New array: ");

            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.ReadLine();
        }
        public static int[] Mid(int[] nums1, int[] nums2)
        {
            return new int[] { nums1[2], nums2[2] };
        }
    }
}
