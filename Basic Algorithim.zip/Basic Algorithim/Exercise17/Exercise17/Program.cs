﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise17
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(word("Python"));
            Console.WriteLine(word("hytades"));
            Console.WriteLine(word("jsues"));
        }

        public static string word(string str)
        {
            return str.Substring(1, 2).Equals("yt") ? str.Remove(1, 2) : str;
        }
    }
}
