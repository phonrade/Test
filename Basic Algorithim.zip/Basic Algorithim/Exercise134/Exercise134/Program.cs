﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise134
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DosFif(new[] { 5, 5, 1, 15, 15 }));
            Console.WriteLine(DosFif(new[] { 15, 2, 3, 4, 15 }));
            Console.WriteLine(DosFif(new[] { 3, 3, 15, 15, 5, 5 }));
            Console.WriteLine(DosFif(new[] { 1, 5, 15, 7, 8, 15 }));
        }

        static bool DosFif(int[] numbers)
        {
            for (int i = 0; i < numbers.Length - 1; i++)
            {
                if (numbers[i + 1] == numbers[i] && numbers[i] == 15) return true;
            }
            return false;
        }
    }
}
