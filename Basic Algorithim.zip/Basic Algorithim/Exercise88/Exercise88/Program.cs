﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise88
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Lengths(new[] { 10, 20, 40, 50 }));
            Console.WriteLine(Lengths(new[] { 5, 20, 40, 10 }));
            Console.WriteLine(Lengths(new[] { 10, 20, 40, 10 }));
            Console.WriteLine(Lengths(new[] { 12, 24, 35, 55 }));
        }

        public static bool Lengths(int[] num)
        {
            return num[0] == 10 || num[num.Length - 1] == 10;
        }
    }
}
