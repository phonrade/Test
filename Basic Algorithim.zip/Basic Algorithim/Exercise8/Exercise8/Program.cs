﻿using System;

namespace Exercise8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(test("C Sharp"));
            Console.WriteLine(test("JS"));
            Console.WriteLine(test("a"));
        }

        public static string test(string str)
        {
            return str.Length < 2 ? str : str.Substring(0, 2) + str.Substring(0, 2) + str.Substring(0, 2) + str.Substring(0, 2);
        }
    }
}
