﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise78
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Fuse("abc", "cat"));
            Console.WriteLine(Fuse("python", "php"));
            Console.WriteLine(Fuse("php", "php"));
        }

        public static string Fuse(string s1, string s2)
        {
            if (s1.Length < 1)
            {
                return s2;
            }

            if (s2.Length < 1)
            {
                return s1;
            }

            return !s1.EndsWith(s2.Substring(0, 1)) ? s1 + s2 : s1 + s2.Substring(1);
        }
    }
}
