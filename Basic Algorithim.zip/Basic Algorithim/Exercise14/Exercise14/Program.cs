﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise14
{
    class Program
    {

        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(example(100));
            Console.WriteLine(example(140));
            Console.WriteLine(example(45));
        }
        public static bool example(int x)
        {
            return x >= 100 && x <= 200;
        }
        */
        
        
        //Actual Solution

        static void Main(string[] args)
        {
            Console.WriteLine(test(100, 199));
            Console.WriteLine(test(250, 300));
            Console.WriteLine(test(105, 190));
            Console.ReadLine();
        }
        public static bool test(int x, int y)
        {
            return (x >= 100 && x <= 200) || (y >= 100 && y <= 200);
        }
        
    }
}
