﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise89
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Lines(new[] { 10, 20, 40, 50 }));
            Console.WriteLine(Lines(new[] { 10, 20, 40, 10 }));
            Console.WriteLine(Lines(new[] { 12, 24, 35, 55 }));
        }

        public static bool Lines(int[] nums)
        {
            return nums.Length > 0 && nums[0] == nums[nums.Length - 1];
        }
    }
}
