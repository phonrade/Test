﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//ACTUALLY EXERCISE34
namespace Exercise33
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(FindNo(new[] { 1, 2, 3, 4 }, 1, 2, 3));
            Console.WriteLine(FindNo(new[] { 5, 1, 3, 2 }, 1, 2, 3));
            Console.WriteLine(FindNo(new[] { 6, 2, 8, 8 }, 1, 2, 3));
            Console.WriteLine(FindNo(new[] { 5, 6, 7, 8 }, 1, 2, 3));
            Console.WriteLine(FindNo(new[] { 1, 1, 3, 2}, 1, 2, 3));
        }

        public static bool FindNo(int [] numbers, int x, int y, int z)
        {
            return numbers.Length < 4 ? numbers.Contains(x) : numbers.Take(4).Contains(x) && numbers.Length < 4 ? numbers.Contains(y) : numbers.Take(4).Contains(y) && numbers.Length < 4 ? numbers.Contains(z) : numbers.Take(4).Contains(z);
        }
        */

        //Actual Answer
        static void Main(string[] args)
        {
            Console.WriteLine(test(new[] { 1, 1, 2, 3, 1 }));
            Console.WriteLine(test(new[] { 1, 1, 2, 4, 1 }));
            Console.WriteLine(test(new[] { 1, 1, 2, 1, 2, 3 }));
            Console.ReadLine();
        }

        public static bool test(int[] nums)
        {
            for (var i = 0; i < nums.Length - 1; i++)
            {
                if (nums[i] == 1 && nums[i + 1] == 2 && nums[i + 2] == 3)
                    return true;
            }
            return false;
        }
    }
}
