﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise21
{
    class Program
    {
        //My Solution
        
        static void Main(string[] args)
        {
            Console.WriteLine(two(60, 70));
            Console.WriteLine(two(25, 28));
            Console.WriteLine(two(10, 15));
            Console.WriteLine(two(30, 20));
            Console.ReadLine();
            Console.WriteLine(two(78, 95));
            Console.WriteLine(two(20, 30));
            Console.WriteLine(two(21, 25));
            Console.WriteLine(two(28, 28));
        }

        public static int two(int x, int y)
        {
            if (x >= 20 && x <= 30 && y >= 20 && y <= 30)
                if (x > y)
                {
                    return x;
                }
                else
                {
                    return y;
                }
            {
                return 0;
            }
        }
        
        //Actual Anwser
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(two(78, 95));
            Console.WriteLine(two(20, 30));
            Console.WriteLine(two(21, 25));
            Console.WriteLine(two(28, 28));
        }

        public static int two(int x, int y)
        {
            if (x >= 20 && x <= 30 && y >= 20 && y <= 30)
                if (x > y)
                {
                    return x;
                }
                else
                {
                    return y;
                }
            else if (x >= 20 && y <= 30)
            {
                return x;
            }
            else if (y >= 20 && x <= 50)
            {
                return y;
            }
            {
                return 0;
            }
        }
        */
    }
}
