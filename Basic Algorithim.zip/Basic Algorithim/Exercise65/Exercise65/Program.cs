﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise65
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Mid("Hello"));
            Console.WriteLine(Mid("Hi"));
            Console.WriteLine(Mid("Python"));
        }

        public static string Mid(string s1)
        {
            return s1.Substring(1)
               .Substring(0, s1.Length - 2);
        }
    }
}
