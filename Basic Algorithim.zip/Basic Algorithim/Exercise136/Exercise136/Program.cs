﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise136
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Number of array: ");
            Console.WriteLine(Num(new[] { "a", "b", "bb", "c", "ccc" }, 1));
        }

        static int Num(string[] arr_str, int len)
        {
            int ctr = 0;

            for (int i = 0; i < arr_str.Length; i++)
            {
                if (arr_str[i].Length == len) ctr++;
            }
            return ctr;
        }
    }
}
