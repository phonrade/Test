﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise139
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Doble(123));
            Console.WriteLine(Doble(13));
            Console.WriteLine(Doble(222));
        }

        public static bool Doble(int n)
        {
            while (n > 0)
            {
                if (n % 10 == 2) return true;
                n /= 10;
            }
            return false;
        }
    }
}
