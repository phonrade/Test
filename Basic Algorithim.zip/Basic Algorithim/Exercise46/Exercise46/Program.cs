﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise46
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(FB("Fizz"));
            Console.WriteLine(FB("Fouzer"));
            Console.WriteLine(FB("Club"));
            Console.WriteLine(FB("FouB"));

        }
        public static string FB(string str)
        {
            if (str.StartsWith("F") && str.EndsWith("B"))
            {
                return "FizzBuzz";
            }
            else if (str.StartsWith("F"))
            {
                return "Fizz";
            }
            else if (str.EndsWith("B"))
            {
                return "Buzz";
            }
            else
            {
                return str;
            }
        }
    }
}
