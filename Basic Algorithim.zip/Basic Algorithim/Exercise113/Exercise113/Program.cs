﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise113
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Five(new[] { 1, 5, 6, 9, 10, 17 }));
            Console.WriteLine(Five(new[] { 1, 5, 5, 9, 10, 17 }));
            Console.WriteLine(Five(new[] { 1, 5, 5, 9, 10, 17, 5, 5 }));
        }

        static bool Five(int[] nums)
        {
            for (int i = 0; i < nums.Length - 1; i++)
            {
                if (nums[i] == 5 && nums[i] == nums[i + 1]) return true;
            }

            return false;
        }
    }
}
