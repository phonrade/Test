﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4
{
    class Program

        //My Solution
    /*
     * {
        static void Main(string[] args)
        {
            Console.WriteLine(num(50));
            Console.WriteLine(num(12));
            Console.WriteLine(num(4));
            Console.WriteLine(num(200));
        }

        public static bool num(int x)
        {
            const int a = 10;
            const int b = 100;
            const int c = 200;

            return x >= a || x <= b || x == c;
        }

        
    }
    */

    //Actual Answer
    {
        static void Main(string[] args)
        {
            Console.WriteLine(test(103));
            Console.WriteLine(test(90));
            Console.WriteLine(test(89));
            Console.ReadLine();
        }
        public static bool test(int x)
        {
            if (Math.Abs(x - 100) <= 10 || Math.Abs(x - 200) <= 10)
                return true;
            return false;
        }
    }
}
