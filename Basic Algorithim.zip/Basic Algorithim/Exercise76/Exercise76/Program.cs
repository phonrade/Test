﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise76
{
    class Program
    {
        //My Answer
        static void Main(string[] args)
        {
            Console.WriteLine(hashtags("Bruh"));
            Console.WriteLine(hashtags("Dude"));
            Console.WriteLine(hashtags("Girl"));
        }

        public static string hashtags(string str)
        {
            return (str.Length >= 2) ? str = str.Substring(0, 2) : str = "##";
        }

        //Actual Answer
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(hashtags("Bruh"));
            Console.WriteLine(hashtags("Dude"));
            Console.WriteLine(hashtags("Girl"));
        }

        public static string hashtags(string str)
        {
            if (str.Length >= 2)
            {
                str = str.Substring(0, 2);
            }
            else if (str.Length > 0)
            {
                str = str.Substring(0, 1) + "#";
            }
            else
            {
                str = "##";
            }
            return str;
        }
        */
    }
}
