﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise101
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = HG(new[] { 1, 5, 7 });
            Console.Write("New Array: ");
            foreach(var i in item)
            {
                Console.Write(i.ToString()+" ");
            }
            Console.WriteLine();
        }
        static int[] HG(int[] num)
        {
            for (var i = 0; i < num.Length - 1; i++)
            {
                if (num[i].Equals(5) && num[i + 1].Equals(7))
                    num[i + 1] = 1;
            }
            return num;
        }
    }
}
