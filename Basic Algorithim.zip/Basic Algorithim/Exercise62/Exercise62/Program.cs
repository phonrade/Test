﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise62
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Last("Alola"));
            Console.WriteLine(Last("Kalos"));
        }

        public static string Last(string str)
        {
            string last2 = str.Substring(str.Length - 2);
            return last2 + last2 + last2;
        }
    }
}
