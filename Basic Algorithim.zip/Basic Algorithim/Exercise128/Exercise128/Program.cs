﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise128
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] item = RFive(new[] { 1, 2, 3, 5, 7 });
            Console.Write("New array: ");
            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.WriteLine();
        }
        static int[] RFive(int[] numbers)
        {
            int size = 0;
            int[] pre_ele_5;
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] == 5)
                {
                    size = i;
                    break;
                }
            }
            pre_ele_5 = new int[size];

            for (int j = 0; j < size; j++)
            {
                pre_ele_5[j] = numbers[j];
            }
            return pre_ele_5;
        }
    }
}
