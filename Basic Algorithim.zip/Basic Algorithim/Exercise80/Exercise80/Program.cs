﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise80
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(test("abc"));
            Console.WriteLine(test("abcdef"));
            Console.WriteLine(test("C"));
            Console.WriteLine(test("xyz"));
            Console.WriteLine(test("xyzsder"));
            Console.ReadLine();
        }

        public static string test(string s1)
        {
            if (s1.StartsWith("abc"))
            {
                return "abc";
            }
            else if (s1.StartsWith("xyz"))
            {
                return "xyz";
            }
            else
            {
                return String.Empty;
            }
        }
    }
}
