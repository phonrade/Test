﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise28
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(dobA("caab"));
            Console.WriteLine(dobA("babaaba"));
            Console.WriteLine(dobA("aaaaa"));
        }

        public static bool dobA(string str)
        {
            var counter = 0;
            for (var i = 0; i < str.Length - 1; i++)
            {
                if (str[i].Equals('a')) counter++;
                if (str.Substring(i, 2).Equals("aa") && counter < 2)
                    return true;
            }
            return false;
        }
    }
}
