﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise41
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(SumDif(5, 10));
            Console.WriteLine(SumDif(15, 10));
            Console.WriteLine(SumDif(53, 38));
            Console.WriteLine(SumDif(5, 5));
        }

        public static bool SumDif(int num1, int num2)
        {
            return num1 == 5 || num2 == 5 || num1 + num2 == 5 || num1 - num2 == 5;
        }
        */

        //Actual Answer
        static void Main(string[] args)
        {
            Console.WriteLine(test(5, 4));
            Console.WriteLine(test(4, 3));
            Console.WriteLine(test(1, 4));
            Console.ReadLine();
        }
        public static bool test(int x, int y)
        {
            return x == 5 || y == 5 || x + y == 5 || Math.Abs(x - y) == 5;
        }
    }
}
