﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise137
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] item = Tres(new[] { "a", "b", "bb", "c", "ccc" }, 3);
            Console.Write("New array: ");
            foreach (var i in item)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.WriteLine();
        }

        static string[] Tres(string[] arr_str, int n)
        {
            string[] new_array = new string[n];

            for (int i = 0; i < n; i++)
            {
                new_array[i] = arr_str[i];
            }

            return new_array;
        }
    }
}
