﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise51
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(Twenty(23, 3, 33));
            Console.WriteLine(Twenty(31, 11, 45));
            Console.WriteLine(Twenty(40, 30, 15));
            Console.WriteLine(Twenty(10, 30, 20));
        }

        public static bool Twenty(int x, int y, int z)
        {
            return x - y == 20 || y - z == 20 || x - z == 20;
        }
        */

        //Actual Answer
        static void Main(string[] args)
        {
            Console.WriteLine(test(11, 21, 31));
            Console.WriteLine(test(11, 22, 31));
            Console.WriteLine(test(10, 20, 15));
            Console.ReadLine();
            Console.WriteLine(test(23, 3, 33));
            Console.WriteLine(test(31, 11, 45));
            Console.WriteLine(test(40, 30, 15));
            Console.WriteLine(test(10, 30, 20));
        }
        public static bool test(int x, int y, int z)
        {
            return Math.Abs(x - y) >= 20 || Math.Abs(x - z) >= 20 ||
                     Math.Abs(y - z) >= 20;
        }
    }
}
