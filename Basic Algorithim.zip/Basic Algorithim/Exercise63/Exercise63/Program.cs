﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise63
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(First("Hello"));
            Console.WriteLine(First("Hi"));
            Console.WriteLine(First("H"));
            Console.WriteLine(First(" "));
        }

        public static string First(string s1)
        {
            return s1.Length < 2 ? s1 : s1.Substring(0, 2);
        }
    }
}
