﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise90
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(LineCheck(new[] { 10, 20, 40, 50 }, new[] { 10, 20, 40, 50 }));
            Console.WriteLine(LineCheck(new[] { 10, 20, 40, 50 }, new[] { 10, 20, 40, 5 }));
            Console.WriteLine(LineCheck(new[] { 10, 20, 40, 50 }, new[] { 1, 20, 40, 5 }));
        }

        public static bool LineCheck(int[] nums1, int[] nums2)
        {
            return nums1[0] == nums2[0] || nums1[nums1.Length - 1] == nums2[nums2.Length - 1];
        }
    }
}
