﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise77
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(test("Hello", "Hi"));
            Console.WriteLine(test("Python", "PHP"));
            Console.WriteLine(test("JS", "JS"));
            Console.WriteLine(test("Csharp", ""));
            Console.ReadLine();
        }

        public static string test(string s1, string s2)
        {
            string lastChars = String.Empty;

            if (s1.Length > 0)
            {
                lastChars += s1.Substring(0, 1);
            }
            else
            {
                lastChars += "#";
            }

            if (s2.Length > 0)
            {
                lastChars += s2.Substring(s2.Length - 1);
            }
            else
            {
                lastChars += "#";
            }

            return lastChars;
        }
    }
}
