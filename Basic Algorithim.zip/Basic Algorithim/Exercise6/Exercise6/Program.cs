﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(python("Python", 1));
            Console.WriteLine(python("Python", 0));
            Console.WriteLine(python("Python", 4));
            Console.WriteLine(python("Python", 5));
            Console.WriteLine(python("Python", 2));
            Console.ReadLine();
        }

        public static string python(string str, int n)
        {
            return str.Remove(n, 1);
        }
    }
}
