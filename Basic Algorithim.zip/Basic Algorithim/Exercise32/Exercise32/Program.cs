﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise32
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(SpefNo(new[] { 1, 2, 2, 3}, 3));
            Console.WriteLine(SpefNo(new[] { 1, 2, 2, 3 }, 2));
            Console.WriteLine(SpefNo(new[] { 1, 2, 2, 3 }, 9));
            Console.WriteLine(SpefNo(new[] { 1, 2, 2, 3 }, 1));
        }
        public static bool SpefNo(int[] numbers, int num)
        {
            return numbers.Length < 4 ? numbers.Contains(num) : numbers.Take(4).Contains(num);
        }
    }
}
