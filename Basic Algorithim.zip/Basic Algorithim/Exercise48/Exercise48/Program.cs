﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise48
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.WriteLine(GL(1, 2, 3));
            Console.WriteLine(GL(23, 10, 54));
            Console.WriteLine(GL(5, 14, 16));
            Console.WriteLine(GL(6, 6, 9));
        }

        public static bool GL (int x, int y, int z)
        {
            return x <= y && y <= z;
        }
        */

        //Actual Answer
        static void Main(string[] args)
        {
            Console.WriteLine(test(1, 2, 3));
            Console.WriteLine(test(4, 5, 6));
            Console.WriteLine(test(-1, 1, 0));
            Console.ReadLine();
        }
        public static bool test(int x, int y, int z)
        {
            return x < y && y < z;
        }

    }
}
