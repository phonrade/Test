﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise42
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Multi(13));
            Console.WriteLine(Multi(15));
            Console.WriteLine(Multi(26));
            Console.WriteLine(Multi(41));
            Console.WriteLine(Multi(14));
        }

        public static bool Multi(int num)
        {
            return num % 13 == 0 || num % 13 == 1;
        }
    }
}
