﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise149
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> mylist = RFour(new List<int>(new int[] { 0, -2, 1, 1, 3, 5, 4, 7, 8 }));
            foreach(var i in mylist)
            {
                Console.Write(i.ToString() + " ");
            }
            Console.WriteLine();
        }

        public static List<int> RFour(List<int> nums)
        {
            return nums.Where(n => n < 4).ToList();
        }
    }
}
