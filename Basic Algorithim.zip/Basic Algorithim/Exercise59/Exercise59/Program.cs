﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise59
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Incr(4, 5, 6));
            Console.WriteLine(Incr(7, 12, 13));
            Console.WriteLine(Incr(-1, 0, 1));
        }

        public static bool Incr(int x, int y, int z)
        {
            if (x > y && x > z && y > z) return x - y == y - z;
            if (x > y && x > z && z > y) return x - z == z - y;
            if (y > x && y > z && x > z) return y - x == x - z;
            if (y > x && y > z && z > x) return y - z == z - x;
            if (z > x && z > y && x > y) return z - x == x - y;
            return z - y == y - x;
        }
    }
}
