﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise57
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Odd(4, 5, 7));
            Console.WriteLine(Odd(7, 4, 12));
            Console.WriteLine(Odd(10, 13, 12));
            Console.WriteLine(Odd(17, 12, 18));
        }

        public static int Odd(int x, int y, int z)
        {
            return Program.fix_num(x) + Program.fix_num(y) + Program.fix_num(z);
        }

        private static int fix_num(int n)
        {
            return (n < 13 && n > 9) || (n > 17 && n < 21) ? 0 : n;
        }
    }
}
