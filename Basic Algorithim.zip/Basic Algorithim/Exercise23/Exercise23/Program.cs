﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise23
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(last(123, 456));
            Console.WriteLine(last(12, 512));
            Console.WriteLine(last(7, 87));
            Console.WriteLine(last(12, 45));
        }

        public static bool last(int x, int y)
        {
            return Math.Abs(x % 10) == Math.Abs(y % 10);
        }
    }
}
