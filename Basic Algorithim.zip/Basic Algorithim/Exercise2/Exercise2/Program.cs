﻿using System;
namespace Exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(test(46));
            Console.WriteLine(test(55));
            Console.WriteLine(test(15));
            Console.ReadLine();
        }

        public static int test(int n)
        {
            const int x = 51;

            if (n > x)
            {
                return (n - x)*3;
            }
            return n - x;
        }
    }
}