﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise56
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Tin(4, 5, 7));
            Console.WriteLine(Tin(7, 4, 12));
            Console.WriteLine(Tin(10, 13, 12));
            Console.WriteLine(Tin(13, 12, 18));
        }

        public static int Tin(int x, int y, int z)
        {
            if (x == 13) return 0;
            if (y == 13) return x;
            if (z == 13) return x + y;
            return x + y + z;
        }
    }
}
