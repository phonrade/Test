﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise37
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(deleter("Python"));
            Console.WriteLine(deleter("JavaScript"));
            Console.WriteLine(deleter("HTML"));
        }

        public static string deleter(string str1)
        {
            var result = string.Empty;
            for (var i = 0; i < str1.Length; i += 4)
            {
                var c = i + 2;
                var n = 0;
                n += c > str1.Length ? 1 : 2;
                result += str1.Substring(i, n);
            }
            return result;
        }
    }
}
