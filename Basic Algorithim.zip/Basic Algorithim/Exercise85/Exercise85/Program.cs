﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise85
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Switcher("abcab"));
            Console.WriteLine(Switcher("python"));
            Console.WriteLine(Switcher("press"));
            Console.WriteLine(Switcher("jython"));
        }

        public static string Switcher(string s1)
        {
            if (s1.Length >= 2)
            {
                if (String.Compare(s1.Substring(1, 1), "y") != 0)
                {
                    s1 = s1.Remove(1, 1);
                }

                if (String.Compare(s1.Substring(0, 1), "p") != 0)
                {
                    s1 = s1.Remove(0, 1);
                }
            }
            else if (s1.Length > 0 && String.Compare(s1.Substring(0, 1), "p") != 0)
            {
                s1 = s1.Remove(0, 1);
            }

            return s1;
        }
    }
}
