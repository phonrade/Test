﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise107
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Increase(new[] { 1 }));
            Console.WriteLine(Increase(new[] { 1, 2, 9 }));
            Console.WriteLine(Increase(new[] { 1, 2, 9, 3, 3 }));
            Console.WriteLine(Increase(new[] { 1, 2, 3, 4, 5, 6, 7 }));
            Console.WriteLine(Increase(new[] { 1, 2, 2, 3, 7, 8, 9, 10, 6, 5, 4 }));
        }

        static int Increase(int[] num)
        {
            int first, middle_ele, last_ele, max_ele;

            first = num[0];
            middle_ele = num[num.Length / 2];
            last_ele = num[num.Length - 1];
            max_ele = first;

            if (middle_ele > max_ele)
            {
                max_ele = middle_ele;
            }
            if (last_ele > max_ele)
            {
                max_ele = last_ele;
            }
            return max_ele;
        }
    }
}
