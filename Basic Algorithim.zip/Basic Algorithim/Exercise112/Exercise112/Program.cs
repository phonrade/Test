﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise112
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sum of the numbers of the said array except those numbers starting with 5 followed by atleast one 6: ");
            Console.WriteLine(Sum(new[] { 1, 5, 6, 9, 10, 17 }));
        }

        static int Sum(int[] nums)
        {
            int sum = 0;
            bool inSection = false;
            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] == 5) inSection = true;
                else if (inSection && nums[i] == 6) inSection = false;
                else if (!inSection) sum += nums[i];
            }
            return sum;
        }
    }
}
