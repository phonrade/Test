﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise52
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(RSeven(11, 21));
            Console.WriteLine(RSeven(11, 20));
            Console.WriteLine(RSeven(10, 10));
        }

        public static int RSeven(int x, int y)
        {
            if (x == y)
            {
                return 0;
            }
            else if ((x % 7 == y % 7 && x < y) || x > y)
            {
                return x;
            }
            else
            {
                return y;
            }
        }
    }
}
