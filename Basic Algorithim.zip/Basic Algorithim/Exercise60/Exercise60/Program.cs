﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise60
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(strings("Hi", "Hello"));
            Console.WriteLine(strings("whats", "app")); 
        }

        public static string strings(string str1, string str2)
        {
            return str1 + str2 + str2 + str1;
        }
    }
}
