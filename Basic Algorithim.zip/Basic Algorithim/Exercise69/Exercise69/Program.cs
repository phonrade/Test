﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise69
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Las("Hello"));
            Console.WriteLine(Las("Pokemon"));
            Console.WriteLine(Las("Voltron"));
        }

        public static string Las(string str)
        {
            return str.Substring(str.Length - 2) + str.Remove(str.Length - 2);
        }
    }
}
