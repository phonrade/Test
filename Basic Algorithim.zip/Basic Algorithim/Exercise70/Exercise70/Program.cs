﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise70
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Rem("Halo"));
            Console.WriteLine(Rem("CallOfDuty"));
            Console.WriteLine(Rem("GodOfWar"));
            Console.WriteLine(Rem("WarCraft"));
        }

        public static string Rem(string str)
        {
            return str.Length < 2 ? String.Empty : str.Substring(1, str.Length - 2);
        }
    }
}
