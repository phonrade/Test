﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise118
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Rem(new[] { 5, 5, 5, 5, 5 }));
            Console.WriteLine(Rem(new[] { 3, 3, 3, 3 }));
            Console.WriteLine(Rem(new[] { 3, 3, 3, 5, 5, 5 }));
            Console.WriteLine(Rem(new[] { 1, 6, 8, 10 }));
        }

        static bool Rem(int[] nums)
        {
            var three = false;
            var five = false;

            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] == 3) { three = true; }
                if (nums[i] == 5) { five = true; }
                if (three && five) return false;
            }
            return true;
        }
    }
}
