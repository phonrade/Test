﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise125
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Spec(new[] { 3, 7, 5, 5, 3, 7 }, 2));
            Console.WriteLine(Spec(new[] { 3, 7, 5, 5, 3, 7 }, 3));
            Console.WriteLine(Spec(new[] { 3, 7, 5, 5, 3, 7, 5 }, 3));
        }

        static bool Spec(int[] numbers, int len)
        {
            int arra_size = numbers.Length;

            for (int i = 0; i < len; i++)
            {
                if (numbers[i] != numbers[arra_size - len + i])
                {
                    return false;
                }
            }

            return true;
        }
    }
}
