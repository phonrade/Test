﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise72
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(ON("Espeon"));
            Console.WriteLine(ON("Umbreon"));
            Console.WriteLine(ON("Leafeon"));
            Console.WriteLine(ON("Glaceon"));
            Console.WriteLine(ON("Evee"));
        }

        public static bool ON(string str)
        {
            return str.EndsWith("on");
        }
    }
}
