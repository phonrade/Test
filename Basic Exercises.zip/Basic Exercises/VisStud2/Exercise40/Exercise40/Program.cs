﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Exercise40
{
    public static void Main()
    {
        /*
        Console.WriteLine("\nInput first integer:");
        int x = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Input second integer:");
        int y = Convert.ToInt32(Console.ReadLine());
        int n = 20;
        var val1 = Math.Abs(x - n);
        var val2 = Math.Abs(y - n);
        Console.WriteLine(val1 == val2 ? 0 : (val1 < val2 ? x : y));
        */

        //My Solution
        Console.WriteLine("Input first number: ");
        int num1 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Input second number: ");
        int num2 = Convert.ToInt32(Console.ReadLine());

        if (num1 <= 20)
        {
            Console.WriteLine("{0} is the output", num1);
        }
        else if (num2 <= 20)
        {
            Console.WriteLine("{0} is the output", num2);
        }
    }
}