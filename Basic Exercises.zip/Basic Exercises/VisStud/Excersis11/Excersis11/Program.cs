﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excersis11
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;

            Console.WriteLine("Enter you age: ");
            age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Your look older than {0}", age);
            Console.ReadLine();


        }
    }
}
