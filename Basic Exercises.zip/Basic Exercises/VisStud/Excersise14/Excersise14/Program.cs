﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excersise14
{
    class Program
    {
        static void Main(string[] args)
        {

            //My Answer

            /*   int deg;

               Console.WriteLine("Enter Celsius: ");
               deg = Convert.ToInt32(Console.ReadLine());
               Console.WriteLine("");

               int add = 273;
               int kel = deg + add;
               Console.WriteLine("To Kelvin: {0}", kel);

               int num1 = 2;
               int num2 = 32;
               int fah = num1 * deg + num2;
               Console.WriteLine("To Fahrenheit: {0}", fah);   */

            //Solution

            Console.Write("Enter the amount of celsius: ");
            int celsius = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Kelvin = {0}", celsius + 273);
            Console.WriteLine("Fahrenheit = {0}", celsius * 18 / 10 + 32);
        }
    }
}
