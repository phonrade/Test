﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excersise10
{
    class Program
    {
        static void Main(string[] args)
        {
            double num1, num2, num3;

            Console.WriteLine("Enter 1st number: ");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter 2nd number: ");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter 3rd number: ");
            num3 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Result of {0}, {1} and {2}, ({0}+{1}).{2} is {3} and " +
                "{0}*{1} + {1}*{2} is {4}\n\n", num1, num2, num3, ((num1+num2)*num3), (num1*num2 + num2*num3));


            /*   int number1, number2, number3;

            Console.Write("Enter first number - ");
            number1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter second number - ");
            number2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter third number - ");
            number3 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Result of specified numbers {0}, {1} and {2}, (x+y)·z is {3} and x·y + y·z is {4}\n\n",
                number1, number2, number3, ((number1 + number2) * number3), (number1 * number2 + number2 * number3));  */
        }
    }
}
