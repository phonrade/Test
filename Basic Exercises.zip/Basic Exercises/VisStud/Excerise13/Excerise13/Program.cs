﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excerise13
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;

            Console.WriteLine("Input number: ");
            num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");

            Console.WriteLine("{0}{0}{0}", num);
            Console.WriteLine("{0} {0}", num);
            Console.WriteLine("{0} {0}", num);
            Console.WriteLine("{0} {0}", num);
            Console.WriteLine("{0}{0}{0}", num);
        }
    }
}
