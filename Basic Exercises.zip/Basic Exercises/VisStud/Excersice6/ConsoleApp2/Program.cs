﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int number1, number2, number3;
            Console.Write("\nInput the First Number : ");
            number1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nInput the Second Number : ");
            number2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nInput the Second Number : ");
            number3 = Convert.ToInt32(Console.ReadLine());

            int result = number1 * number2 * number3;
            Console.Write("Answer: {0} x {1} x {2} = {3}", number1, number2, number3, result);
            Console.Read();
        }
    }
}
