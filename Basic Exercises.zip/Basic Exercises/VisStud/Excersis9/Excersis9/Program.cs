﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excersis9
{
    class Program
    {
        static void Main(string[] args)
        {
            //My Solution

        /*    int num1;
            int num2;
            int num3;
            int num4;
           
            Console.WriteLine("Enter 1st number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2nd number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 3rd number: ");
            num3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 4th number: ");
            num4 = Convert.ToInt32(Console.ReadLine());

            int result = (num1 + num2 + num3 + num4) / 4;
            Console.WriteLine("Average of {0}, {1}, {2}, {3} is: {4}", num1, num2, num3, num4, result); */

            //Solution

            double number1, number2, number3, number4;

            Console.Write("Enter the First number: ");
            number1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the Second number: ");
            number2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the third number: ");
            number3 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the fourth number: ");
            number4 = Convert.ToDouble(Console.ReadLine());

            double result = (number1 + number2 + number3 + number4) / 4;
            Console.WriteLine("The average of {0}, {1}, {2}, {3} is: {4} ",
         number1, number2, number3, number4, result);


        }
    }
}
