﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excersice7
{
    class Program
    {
        static void Main(string[] args)
        {
            //My Answer

            /* int number1, number2, number3;
            Console.Write("\nInput the First Number : ");
            number1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nInput the Second Number : ");
            number2 = Convert.ToInt32(Console.ReadLine());

            int sum = number1 + number2;
            int product = number1 * number2;
            int difference = number1 - number2;
            int result = number1 / number2;
            Console.WriteLine("Answer: {0} + {1} = {2}", number1, number2, sum);
            Console.WriteLine("Answer: {0} * {1} = {2}", number1, number2, product);
            Console.WriteLine("Answer: {0} - {1} = {2}", number1, number2, difference);
            Console.WriteLine("Answer: {0} / {1} = {2}", number1, number2, result);
            Console.Read(); */

            //Solution

            Console.Write("Enter a number: ");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter another number: ");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("{0} + {1} = {2}", num1, num2, num1 + num2);
            Console.WriteLine("{0} - {1} = {2}", num1, num2, num1 - num2);
            Console.WriteLine("{0} x {1} = {2}", num1, num2, num1 * num2);
            Console.WriteLine("{0} / {1} = {2}", num1, num2, num1 / num2);
            Console.WriteLine("{0} mod {1} = {2}", num1, num2, num1 % num2);
        }
    }
}
