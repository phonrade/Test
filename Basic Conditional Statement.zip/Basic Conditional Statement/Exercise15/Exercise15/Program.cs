﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise15
{
    class Program
    {
        static void Main(string[] args)
        {
            int ang1, ang2, ang3, sum;

            Console.WriteLine("Input first angle of triangle: ");
            ang1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input second angle of triangle: ");
            ang2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input third angle of triangle: ");
            ang3 = Convert.ToInt32(Console.ReadLine());

            sum = ang1 + ang2 + ang3;

            if(sum == 180)
            {
                Console.WriteLine("The triangle is valid");
            }
            else
            {
                Console.WriteLine("The triangle is invalid");
            }
        }
    }
}
