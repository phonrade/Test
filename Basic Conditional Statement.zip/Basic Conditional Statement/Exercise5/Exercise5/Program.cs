﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise5
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;

            Console.WriteLine("Type your age: ");
            age = Convert.ToInt32(Console.ReadLine());

            if (age >= 18)
                Console.WriteLine("Congratulation! You're eligible to vote.");
            else
            {
                Console.WriteLine("You are not in legal age.");
                Console.WriteLine("You would be able to vote in {0} year(s).", 18-age);
            }
        }
    }
}
