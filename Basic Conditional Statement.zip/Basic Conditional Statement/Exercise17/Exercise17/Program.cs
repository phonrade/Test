﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise17
{
    class Program
    {
        static void Main(string[] args)
        {
            int cost, sell, profit;

            Console.Write("Input the cost price: ");
            cost = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input the selling price: ");
            sell = Convert.ToInt32(Console.ReadLine());

            if(sell>cost)
            {
                profit = sell - cost;
                    Console.WriteLine("You can book your profit amount: {0}", profit);
            }
            else if(cost>sell)
            {
                profit = cost - sell;
                    Console.WriteLine("Total of amount loss: {0}", profit);
            }
            else
            {
                Console.WriteLine("You are running in no profit no loss condition");
            }
        }
    }
}
