﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Check whether a number is positive or negative: ");
            Console.WriteLine("Input Integer: ");
            num = Convert.ToInt32(Console.ReadLine());

            if (num >= 0)
                Console.WriteLine("{0} is a positive number", num);
            else
                Console.WriteLine("{0} is a negative number", num);
        }
    }
}
