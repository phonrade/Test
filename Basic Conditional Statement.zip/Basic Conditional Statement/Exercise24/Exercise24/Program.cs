﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise24
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice, r, l, w, b, h;
            double area = 0;

            Console.WriteLine("Input 1 for area of Circle");
            Console.WriteLine("Input 2 for area of Rectangle");
            Console.WriteLine("Input 3 for area of Triangle");
            Console.WriteLine();
            Console.WriteLine("Press ENTER to continue");
            Console.ReadLine();
            Console.Write("Input your choice: ");
            choice = Convert.ToInt32(Console.ReadLine());

            switch(choice)
            {
                case 1:
                    Console.Write("Input radius of the circle: ");
                    r = Convert.ToInt32(Console.ReadLine());
                    area = 3.14 * r * r;
                    break;
                case 2:
                    Console.Write("Input length of rectangle: ");
                    l = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Input width of rectangle: ");
                    w = Convert.ToInt32(Console.ReadLine());
                    break;
                case 3:
                    Console.Write("Input base of triangle: ");
                    b = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Input height of the triangle: ");
                    h = Convert.ToInt32(Console.ReadLine());
                    area = .5 * b * h;
                    break;
                default:
                    Console.WriteLine("In correct input. Please try again . . .");
                    break;
            }
            Console.WriteLine("The area is: {0}", area);
        }
    }
}
