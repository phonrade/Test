﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise8
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            Console.Write("Input first number: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input second number: ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input thrid number: ");
            int num3 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();

            if (num1 >= num2 && num1 >= num3)
                Console.WriteLine("{0} is the largest number", num1);
            else if (num2 >= num1 && num2 >= num3)
                    Console.WriteLine("{0} is the largest number", num2);
            else if (num3 >= num1 && num3 >= num1)
                    Console.WriteLine("{0} is the largest number", num3);
            else
                Console.WriteLine();

            Console.WriteLine();
        }
        */

        //Actual Answer
        public static void Main()
        {
            int num1, num2, num3;
            Console.Write("\n\n");
            Console.Write("Find the largest of three numbers:\n");
            Console.Write("------------------------------------");
            Console.Write("\n\n");

            Console.Write("Input the 1st number :");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input the  2nd number :");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input the 3rd  number :");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2)
            {
                if (num1 > num3)
                {
                    Console.Write("The 1st Number is the greatest among three. \n\n");
                }
                else
                {
                    Console.Write("The 3rd Number is the greatest among three. \n\n");
                }
            }
            else if (num2 > num3)
                Console.Write("The 2nd Number is the greatest among three \n\n");
            else
                Console.Write("The 3rd Number is the greatest among three \n\n");
        }
    }
}
