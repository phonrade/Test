﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise11
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;

            double d, x1, x2;
            Console.WriteLine("Calculate root of Quadratic Equation");

            Console.Write("Input of value A: ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input of value B: ");
            b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input of value C: ");
            c = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();

            d = b * b - 4 * a * c;

            if(d == 0)
            {
                Console.WriteLine("Both roots are equal.");
                x1 = -b / (2.0 * a);
                x2 = x1;
                Console.WriteLine("First Root Root1 = {0}", x1);
                Console.WriteLine("Second Root Root2 = {0}", x2);
            }
            else if(d>0)
            {
                Console.WriteLine("Both roots are real and diff-2");

                x1 = (-b + Math.Sqrt(d) / (2 * a));
                x2 = (-b - Math.Sqrt(d) / (2 * a));

                Console.WriteLine("First Root Root1 = {0}", x1);
                Console.WriteLine("Second Root Root2 = {0}", x2);
            }
            else
                Console.WriteLine("Root are imeainary; No Solution");
        }
    }
}
