﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise6
{
    class Program
    {
        static void Main(string[] args)
        {
            int m, n;

            Console.WriteLine("Display the value of n is 1, 0 and -1 for the vaue of er m");
            Console.Write("Input the value of m: ");
            m = Convert.ToInt32(Console.ReadLine());

            if (m != 0)
                if (m > 0)
                    n = 1;
                else
                    n = -1;
            else
                n = 0;

            Console.WriteLine("The value of m = {0}", m);
            Console.WriteLine("The value of n = {0}", n);
        }
    }
}
