﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise13
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            int temp;

            Console.WriteLine("Write the temperature: ");
            temp = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            if (temp <= 0)
                Console.WriteLine("Freezing weather!");
            else if (temp > 0 && temp <= 10)
                Console.WriteLine("Very cold weather!");
            else if (temp > 10 && temp <= 20)
                Console.WriteLine("Cold weather.");
            else if (temp > 20 && temp <= 30)
                Console.WriteLine("Normal temperature.");
            else if (temp > 30 && temp <= 40)
                Console.WriteLine("It's hot!");
            else
                Console.WriteLine("It's very hot!");
        }
        */

        //Actual Answer
        public static void Main()
        {
            int tmp;
            Console.Write("\n\n");
            Console.Write("Accept a temperature in centigrade and display a suitable message:\n");
            Console.Write("--------------------------------------------------------------------");
            Console.Write("\n\n");

            Console.Write("Input days temperature : ");
            tmp = Convert.ToInt32(Console.ReadLine());
            if (tmp < 0)
                Console.Write("Freezing weather.\n");
            else if (tmp < 10)
                Console.Write("Very cold weather.\n");
            else if (tmp < 20)
                Console.Write("Cold weather.\n");
            else if (tmp < 30)
                Console.Write("Normal in temp.\n");
            else if (tmp < 40)
                Console.Write("Its Hot.\n");
            else
                Console.Write("Its very hot.\n");

        }
    }
}
