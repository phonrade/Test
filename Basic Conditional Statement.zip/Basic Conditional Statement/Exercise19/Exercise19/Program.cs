﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise19
{
    class Program
    {
        //My Solution
        /*
        static void Main(string[] args)
        {
            char grade;

            Console.WriteLine("Input your grade: ");
            grade = Convert.ToChar(Console.ReadLine());

            if(grade == 'e' || grade == 'E')
                Console.WriteLine("You have chosen: Excellent");
            else if (grade == 'v' || grade == 'V')
                Console.WriteLine("You have chosen: Very Good");
            else if (grade == 'g' || grade == 'G')
                Console.WriteLine("You have chosen: Good");
            else if (grade == 'a' || grade == 'A')
                Console.WriteLine("You have chosen: Average");
            else if (grade == 'f' || grade == 'F')
                Console.WriteLine("You have chosen: Fail");
            else
                Console.WriteLine("ERROR: Incorrect grade inputted");
        }
        */

        //Actual Answer
        static void Main(string[] args)
        {
            string notes;
            char grd;
            Console.Write("\n\n");
            Console.Write("Accept a grade and display equivalent description:\n");
            Console.Write("---------------------------------------------------");
            Console.Write("\n\n");


            Console.Write("Input the grade :");
            grd = Convert.ToChar(Console.ReadLine().ToUpper());

            switch (grd)
            {
                case 'E':
                    notes = " Excellent";
                    break;
                case 'V':
                    notes = " Very Good";
                    break;
                case 'G':
                    notes = " Good ";
                    break;
                case 'A':
                    notes = " Average";
                    break;
                case 'F':
                    notes = " Fails";
                    break;
                default:
                    notes = "Invalid Grade Found.";
                    break;
            }
            Console.Write("You have chosen  : {0}\n", notes);
        }
    }
}
