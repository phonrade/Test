﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise10
{
    class Program
    {
        static void Main(string[] args)
        {
            int p, c, m;

            Console.WriteLine("Find eligibility for admission");
            Console.WriteLine();
            Console.WriteLine("Eligibility Criteria:");
            Console.WriteLine("Marks in Maths >= 65");
            Console.WriteLine("Marks in Phy >= 55");
            Console.WriteLine("Marks in Chem >= 50");
            Console.WriteLine("and Total in all three subject >= 180");
            Console.WriteLine("or Total in Maths and Physics >= 140");
            Console.WriteLine();

            Console.WriteLine("Input marks obtained in Physics: ");
            p = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input marks obtained in Chemistry: ");
            c = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input marks obtained in Mathematics: ");
            m = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Total marks of Math, Physics and Chemistry: {0}", m + p + c);
            Console.WriteLine("Total marks of Math and Physic: {0}", m+p);

            if (m >= 65)
                if (p >= 55)
                    if (c >= 50)
                        if ((m + p + c) >= 180 || (m + p) >= 140)
                            Console.WriteLine("The candidates is egilible for admission");
            else
                            Console.WriteLine("Canditates is not eligible");
            else
                        Console.WriteLine("Canditates is not eligible");
            else
                    Console.WriteLine("Canditates is not eligible");
            else
                Console.WriteLine("Canditates is not eligible");
        }
    }
}
