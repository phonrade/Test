﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise23
{
    class Program
    {
        static void Main(string[] args)
        {
            int monthNo;

            Console.WriteLine("Input Month No.: ");
            monthNo = Convert.ToInt32(Console.ReadLine());

            switch(monthNo)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    Console.WriteLine("Month has 31 days");
                    Console.ReadLine();
                    break;
                case 2:
                    Console.WriteLine("The 2nd month is a February and have 28 days");
                    Console.WriteLine();
                    Console.WriteLine("in leap year The February month  Have 29 days");
                    Console.ReadLine();
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    Console.WriteLine("Month has 30 days");
                    Console.ReadLine();
                    break;
                default:
                    Console.WriteLine("Invalid Number");
                    Console.ReadLine();
                    break;
            }
        }
    }
}
