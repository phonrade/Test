﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise7
{
    class Program
    {
        static void Main(string[] args)
        {
            float PerHeight;
            Console.WriteLine("Accept the height of a person in centimeter and categorize them:");

            Console.WriteLine("Input the height your person(in centimeter): ");
            PerHeight = Convert.ToInt32(Console.ReadLine());

            if(PerHeight < 150.0)
                Console.WriteLine("You are a dwarf");
            else if ((PerHeight >= 150.0) && (PerHeight <= 165.0))
                Console.WriteLine("You have an average height");
            else if ((PerHeight >= 165.0) && (PerHeight <= 195.0))
                Console.WriteLine("You are taller than the average height");
            else
                Console.WriteLine("You have an abnormal height");
        }
    }
}
