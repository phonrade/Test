﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, rem;

            Console.WriteLine("Check whether a number is even or odd: ");
            Console.Write("Input integer: ");
            num = Convert.ToInt32(Console.ReadLine());
            rem = num % 2;
            if (rem == 0)
                Console.WriteLine("{0} is an even number", num);
            else
                Console.WriteLine("{0} is an odd number", num);
        }
    }
}
