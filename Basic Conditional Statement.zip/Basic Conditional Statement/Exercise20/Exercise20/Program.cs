﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise20
{
    class Program
    {
        static void Main(string[] args)
        {
            int day;

            Console.WriteLine("Input day number: ");
            day = Convert.ToInt32(Console.ReadLine());

            switch(day)
            {
                case 1:
                    Console.WriteLine("The day is, Monday");
                    break;
                case 2:
                    Console.WriteLine("The day is, Tuesday");
                    break;
                case 3:
                    Console.WriteLine("The day is, Wednesday");
                    break;
                case 4:
                    Console.WriteLine("The day is, Thursday");
                    break;
                case 5:
                    Console.WriteLine("The day is, Friday");
                    break;
                case 6:
                    Console.WriteLine("The day is, Saturday");
                    break;
                case 7:
                    Console.WriteLine("The day is, Sunday");
                    break;
                default :
                    Console.WriteLine("Incorrect Input");
                    break;

            }
        }
    }
}
